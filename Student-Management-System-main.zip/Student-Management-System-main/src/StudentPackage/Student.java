package StudentPackage;

public class Student 
{

	public static void main(String[] args) 
	{
		AdminLogin login=new AdminLogin();
		login.adminLogin();
	}

}
